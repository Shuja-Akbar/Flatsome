<?php

return array("preset_home" => 'Grid Style 2',"body_layout" => "boxed","box_shadow" => "1","site_width" => "1090","site_width_boxed" => "1170","body_bg" => "#E2E2E2","flatsome_version" => array("3"),"header_bg" => "rgba(244,244,244,0.9)","footer_bottom_align" => "center","color_primary" => "#58AAAA",);